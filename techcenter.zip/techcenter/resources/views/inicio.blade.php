<!DOCTYPE html>
<!-- Página de TechCenter para la clase del INTECAP -->
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechCenter - Soluciones Informáticas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Mis estilos van después de Bootstrap, si no este se los come -->
    <link rel="stylesheet" href="{{ asset('css/estilos.css') }}">
</head>

<body>
    <!-- La barra de arriba, la que se queda pegada cuando hacés scroll -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">TechCenter</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="menu">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#inicio">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#servicios">Servicios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#recomendaciones">Recomendaciones</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#galeria">Galería</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contacto">Contacto</a>
                    </li>
                </ul>
                <button type="button" id="btnModo" class="btn btn-outline-light btn-sm ms-lg-3 btn-modo" aria-pressed="false" aria-label="Modo oscuro">
                    <svg class="icono-luna" viewBox="0 0 24 24" aria-hidden="true">
                        <path fill="currentColor" d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                    </svg>
                    <svg class="icono-sol" viewBox="0 0 24 24" aria-hidden="true">
                        <circle cx="12" cy="12" r="4" fill="currentColor"></circle>
                        <g stroke="currentColor" stroke-width="2" stroke-linecap="round">
                            <line x1="12" y1="2" x2="12" y2="5"></line>
                            <line x1="12" y1="19" x2="12" y2="22"></line>
                            <line x1="2" y1="12" x2="5" y2="12"></line>
                            <line x1="19" y1="12" x2="22" y2="12"></line>
                            <line x1="4.9" y1="4.9" x2="7" y2="7"></line>
                            <line x1="17" y1="17" x2="19.1" y2="19.1"></line>
                            <line x1="19.1" y1="4.9" x2="17" y2="7"></line>
                            <line x1="7" y1="17" x2="4.9" y2="19.1"></line>
                        </g>
                    </svg>
                </button>
            </div>
        </div>
    </nav>

    <main id="inicio">
        <!-- La bienvenida grande, para que se note de una -->
        <section class="hero">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7">
                        <h1 class="display-4 fw-bold">Servicios Informáticos y Venta de Hardware</h1>
                        <p class="lead">Mantenimiento de computadoras, ensamble de equipos y soporte especializado en Guatemala.</p>
                        <a href="#servicios" class="btn btn-light btn-lg me-2">Ver Servicios</a>
                        <a href="#contacto" class="btn btn-outline-light btn-lg">Contáctanos</a>
                    </div>
                    <div class="col-lg-5 text-center mt-4 mt-lg-0">
                        <div class="hero-card">
                            <div class="display-1">🖥️</div>
                            <p>Ensamble & Mantenimiento</p>
                            <h3>TechCenter</h3>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Lo que sí hacemos, no puro cuento -->
        <section id="servicios" class="py-5">
            <div class="container">
                <div class="text-center mb-5">
                    <h2 class="section-title">Nuestros Servicios</h2>
                    <p class="text-muted">Soluciones integrales para equipos de escritorio, laptops y redes informáticas</p>
                </div>
                <div class="row g-4">
                    <div class="col-md-4">
                        <div class="card service-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="service-icon">🖥️</div>
                                <h4>Reparación y Mantenimiento</h4>
                                <p class="text-muted">
                                    Limpieza técnica profunda, cambio de pasta térmica, instalación de SSD y optimización del sistema operativo.
                                </p>
                                <a href="#contacto" class="btn btn-success">Solicitar Servicio</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card service-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="service-icon">🦾🤖</div>
                                <h4>Ensamble de PC Gamer y Workstation</h4>
                                <p class="text-muted">
                                    Asesoría personalizada en selección de componentes, montaje profesional y pruebas de rendimiento.
                                </p>
                                <a href="#contacto" class="btn btn-success">Cotizar Ensamble</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card service-card h-100">
                            <div class="card-body text-center p-4">
                                <div class="service-icon">🌐</div>
                                <h4>Redes e Infraestructura</h4>
                                <p class="text-muted">
                                    Configuración de redes locales, cableado estructurado, servidores y conectividad para hogares y oficinas.
                                </p>
                                <a href="#contacto" class="btn btn-success">Solicitar Diagnóstico</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Tips para que no se les muera la compu -->
        <section id="recomendaciones" class="py-5 bg-light">
            <div class="container">
                <div class="text-center mb-4">
                    <h2>Recomendaciones para el Cuidado de tu PC</h2>
                </div>
                <div class="accordion accordion-flush shadow-sm rounded border" id="accordionFlushExample">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                Mantén tu sistema actualizado
                            </button>
                        </h2>
                        <div id="flush-collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">
                                Instala las actualizaciones de Windows/Linux y de tus programas con regularidad. Estas incluyen parches de seguridad y mejoras de rendimiento que protegen tu equipo contra vulnerabilidades.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                Cuida el hardware físico
                            </button>
                        </h2>
                        <div id="flush-collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">
                                Limpia el teclado, la pantalla y las rejillas de ventilación para evitar acumulación de polvo que pueda causar sobrecalentamiento. Además, evita comer o beber cerca del equipo para prevenir accidentes.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                                Gestiona bien tus archivos y programas
                            </button>
                        </h2>
                        <div id="flush-collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">
                                Organiza tus documentos en carpetas, elimina lo que ya no necesitas y desinstala aplicaciones que no uses. Esto ayuda a liberar espacio en tu almacenamiento SSD/HDD y mejora la velocidad del sistema.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Fotos, para que vean que el taller existe -->
        <section id="galeria" class="py-5">
            <div class="container">
                <div class="text-center mb-4">
                    <h2>Galería de Equipos y Proyectos</h2>
                </div>
                <div id="carouselExampleIndicators" class="carousel slide shadow rounded overflow-hidden">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="https://images.unsplash.com/photo-1587202372775-e229f172b9d7?auto=format&fit=crop&w=1200&q=80"
                                class="d-block w-100 galeria-img" alt="Taller de Computación">
                        </div>
                        <div class="carousel-item">
                            <img src="https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?auto=format&fit=crop&w=1200&q=80"
                                class="d-block w-100 galeria-img" alt="Procesadores y Hardware">
                        </div>
                        <div class="carousel-item">
                            <img src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=1200&q=80"
                                class="d-block w-100 galeria-img" alt="Mantenimiento de Redes">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Anterior</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Siguiente</span>
                    </button>
                </div>
            </div>
        </section>

        <!-- Aquí dejan sus datos y después les hablamos -->
        <section id="contacto" class="py-5 bg-light">
            <div class="container">
                <div class="text-center mb-5">
                    <h2 class="section-title">Contacto</h2>
                    <p>Puedes dejar tus datos y con gusto te estaremos contactando</p>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-7">
                        <div class="contact-card">
                            <form id="formContacto">
                                <div class="mb-3">
                                    <label class="form-label">Nombre</label>
                                    <input type="text" class="form-control" required placeholder="Escriba su nombre">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Correo Electrónico</label>
                                    <input type="email" class="form-control" required placeholder="nombre@ejemplo.com">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Teléfono</label>
                                    <input type="text" class="form-control" required placeholder="Escriba su número telefónico">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Seleccione su servicio</label>
                                    <select class="form-select" required>
                                        <option value="" selected>Selecciona una opción</option>
                                        <option>Reparación de computadoras</option>
                                        <option>Mantenimiento de PC</option>
                                        <option>Ensamble de PC Gamer / Trabajo</option>
                                        <option>Redes e Internet</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Mensaje</label>
                                    <textarea class="form-control" rows="3" placeholder="Escriba aquí los detalles de su consulta..."></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary w-100">Enviar información</button>
                            </form>

                            <!-- El avisito de que ya quedó; lo prende noche.js -->
                            <div id="mensajeExito" class="mensaje shadow rounded">
                                <h4 class="text-primary mb-3">¡Información Enviada!</h4>
                                <p>Puedes dejar tus datos y con gusto te estaremos contactando.</p>
                                <button id="btnCerrarMensaje" class="btn btn-secondary">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- El pie: nombre, lugar y el copyright -->
    <footer class="footer">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h3>TechCenter</h3>
                    <p class="mb-0">Servicios Informáticos y Venta de Hardware en Guatemala</p>
                </div>
                <div class="col-md-6 text-md-end mt-3 mt-md-0">
                    <p class="mb-0">&copy; 2026 Todos los derechos reservados</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- El JS de Bootstrap, el que mueve el acordeón y la galería -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

    <!-- Nuestro script: el sol, la luna y el formulario -->
    <script src="{{ asset('js/noche.js') }}"></script>
</body>

</html>